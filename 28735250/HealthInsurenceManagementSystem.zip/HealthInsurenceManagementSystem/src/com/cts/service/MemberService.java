package com.cts.service;

import com.cts.dao.MemberDAO;
import com.cts.model.Member;
import com.cts.customexception.ApplicationException;

import java.sql.SQLException;
import java.util.List;

public class MemberService {
    private final MemberDAO memberDAO = new MemberDAO();

    public void addMember(Member member) {
        try {
            memberDAO.addMember(member);
        } catch (SQLException e) {
            throw new ApplicationException("Error adding member: " + e.getMessage(), e);
        }
    }

    public List<Member> getAllMembers() {
        try {
            return memberDAO.getAllMembers();
        } catch (SQLException e) {
            throw new ApplicationException("Error retrieving members: " + e.getMessage(), e);
        }
    }

    public void updateMember(Member member) {
        try {
            memberDAO.updateMember(member);
        } catch (SQLException e) {
            throw new ApplicationException("Error updating member: " + e.getMessage(), e);
        }
    }

    public void deleteMember(int memberId) {
        try {
            memberDAO.deleteMember(memberId);
        } catch (SQLException e) {
            throw new ApplicationException("Error deleting member: " + e.getMessage(), e);
        }
    }
}

