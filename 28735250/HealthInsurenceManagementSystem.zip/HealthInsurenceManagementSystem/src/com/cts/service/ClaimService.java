package com.cts.service;

import com.cts.dao.ClaimDAO;
import com.cts.model.Claim;
import com.cts.customexception.ApplicationException;

import java.sql.SQLException;
import java.util.List;

public class ClaimService {
    private final ClaimDAO claimDAO = new ClaimDAO();

    public void addClaim(Claim claim) {
        try {
            claimDAO.addClaim(claim);
        } catch (SQLException e) {
            throw new ApplicationException("Error adding claim: " + e.getMessage(), e);
        }
    }

    public List<Claim> getAllClaims() {
        try {
            return claimDAO.getAllClaims();
        } catch (SQLException e) {
            throw new ApplicationException("Error retrieving claims: " + e.getMessage(), e);
        }
    }

    public void updateClaim(Claim claim) {
        try {
            claimDAO.updateClaim(claim);
        } catch (SQLException e) {
            throw new ApplicationException("Error updating claim: " + e.getMessage(), e);
        }
    }

    public void deleteClaim(int claimId) {
        try {
            claimDAO.deleteClaim(claimId);
        } catch (SQLException e) {
            throw new ApplicationException("Error deleting claim: " + e.getMessage(), e);
        }
    }
}

