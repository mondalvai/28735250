package com.cts.service;

import com.cts.dao.PolicyDAO;
import com.cts.model.Policy;
import com.cts.customexception.ApplicationException;

import java.sql.SQLException;
import java.util.List;

public class PolicyService {
    private final PolicyDAO policyDAO = new PolicyDAO();

    public void addPolicy(Policy policy) {
        try {
            policyDAO.addPolicy(policy);
        } catch (SQLException e) {
            throw new ApplicationException("Error adding policy: " + e.getMessage(), e);
        }
    }

    public List<Policy> getAllPolicies() {
        try {
            return policyDAO.getAllPolicies();
        } catch (SQLException e) {
            throw new ApplicationException("Error retrieving policies: " + e.getMessage(), e);
        }
    }

    public void updatePolicy(Policy policy) {
        try {
            policyDAO.updatePolicy(policy);
        } catch (SQLException e) {
            throw new ApplicationException("Error updating policy: " + e.getMessage(), e);
        }
    }

    public void deletePolicy(int policyId) {
        try {
            policyDAO.deletePolicy(policyId);
        } catch (SQLException e) {
            throw new ApplicationException("Error deleting policy: " + e.getMessage(), e);
        }
    }
}

