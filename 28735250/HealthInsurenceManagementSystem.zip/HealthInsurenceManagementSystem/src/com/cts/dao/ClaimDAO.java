package com.cts.dao;

import com.cts.model.Claim;
import com.cts.util.DBConnection;
import com.cts.customexception.ApplicationException;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ClaimDAO {
    private static final String INSERT_CLAIM_SQL = "INSERT INTO Claim (policy_id, member_id, claim_date, status) VALUES (?, ?, ?, ?)";
    private static final String SELECT_ALL_CLAIMS_SQL = "SELECT * FROM Claim";
    private static final String UPDATE_CLAIM_SQL = "UPDATE Claim SET policy_id = ?, member_id = ?, claim_date = ?, status = ? WHERE claim_id = ?";
    private static final String DELETE_CLAIM_SQL = "DELETE FROM Claim WHERE claim_id = ?";

    public void addClaim(Claim claim) throws SQLException {
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(INSERT_CLAIM_SQL)) {
            preparedStatement.setInt(1, claim.getPolicyId());
            preparedStatement.setInt(2, claim.getMemberId());
            preparedStatement.setDate(3, new java.sql.Date(claim.getClaimDate().getTime()));
            preparedStatement.setString(4, claim.getStatus());
            preparedStatement.executeUpdate();
        }
    }

    public List<Claim> getAllClaims() throws SQLException {
        List<Claim> claims = new ArrayList<>();
        try (Connection connection = DBConnection.getConnection();
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(SELECT_ALL_CLAIMS_SQL)) {
            while (resultSet.next()) {
                Claim claim = new Claim();
                claim.setClaimId(resultSet.getInt("claim_id"));
                claim.setPolicyId(resultSet.getInt("policy_id"));
                claim.setMemberId(resultSet.getInt("member_id"));
                claim.setClaimDate(resultSet.getDate("claim_date"));
                claim.setStatus(resultSet.getString("status"));
                claims.add(claim);
            }
        }
        return claims;
    }

    public void updateClaim(Claim claim) throws SQLException {
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(UPDATE_CLAIM_SQL)) {
            preparedStatement.setInt(1, claim.getPolicyId());
            preparedStatement.setInt(2, claim.getMemberId());
            preparedStatement.setDate(3, new java.sql.Date(claim.getClaimDate().getTime()));
            preparedStatement.setString(4, claim.getStatus());
            preparedStatement.setInt(5, claim.getClaimId());
            preparedStatement.executeUpdate();
        }
    }

    public void deleteClaim(int claimId) throws SQLException {
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(DELETE_CLAIM_SQL)) {
            preparedStatement.setInt(1, claimId);
            preparedStatement.executeUpdate();
        }
    }
}

