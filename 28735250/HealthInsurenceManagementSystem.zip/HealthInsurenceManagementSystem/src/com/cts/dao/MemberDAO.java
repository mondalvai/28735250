package com.cts.dao;

import com.cts.model.Member;
import com.cts.util.DBConnection;
import com.cts.customexception.ApplicationException;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class MemberDAO {
    private static final String INSERT_MEMBER_SQL = "INSERT INTO Member (name, date_of_birth, email, phone_number) VALUES (?, ?, ?, ?)";
    private static final String SELECT_ALL_MEMBERS_SQL = "SELECT * FROM Member";
    private static final String UPDATE_MEMBER_SQL = "UPDATE Member SET name = ?, date_of_birth = ?, email = ?, phone_number = ? WHERE member_id = ?";
    private static final String DELETE_MEMBER_SQL = "DELETE FROM Member WHERE member_id = ?";

    public void addMember(Member member) throws SQLException {
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(INSERT_MEMBER_SQL)) {
            preparedStatement.setString(1, member.getName());
            preparedStatement.setDate(2, new java.sql.Date(member.getDateOfBirth().getTime()));
            preparedStatement.setString(3, member.getEmail());
            preparedStatement.setString(4, member.getPhoneNumber());
            preparedStatement.executeUpdate();
        }
    }

    public List<Member> getAllMembers() throws SQLException {
        List<Member> members = new ArrayList<>();
        try (Connection connection = DBConnection.getConnection();
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(SELECT_ALL_MEMBERS_SQL)) {
            while (resultSet.next()) {
                Member member = new Member();
                member.setMemberId(resultSet.getInt("member_id"));
                member.setName(resultSet.getString("name"));
                member.setDateOfBirth(resultSet.getDate("date_of_birth"));
                member.setEmail(resultSet.getString("email"));
                member.setPhoneNumber(resultSet.getString("phone_number"));
                members.add(member);
            }
        }
        return members;
    }

    public void updateMember(Member member) throws SQLException {
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(UPDATE_MEMBER_SQL)) {
            preparedStatement.setString(1, member.getName());
            preparedStatement.setDate(2, new java.sql.Date(member.getDateOfBirth().getTime()));
            preparedStatement.setString(3, member.getEmail());
            preparedStatement.setString(4, member.getPhoneNumber());
            preparedStatement.setInt(5, member.getMemberId());
            preparedStatement.executeUpdate();
        }
    }

    public void deleteMember(int memberId) throws SQLException {
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(DELETE_MEMBER_SQL)) {
            preparedStatement.setInt(1, memberId);
            preparedStatement.executeUpdate();
        }
    }
}
