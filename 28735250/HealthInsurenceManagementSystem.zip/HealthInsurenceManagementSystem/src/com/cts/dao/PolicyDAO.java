package com.cts.dao;

import com.cts.model.Policy;
import com.cts.util.DBConnection;
import com.cts.customexception.ApplicationException;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PolicyDAO {
    private static final String INSERT_POLICY_SQL = "INSERT INTO Policy (policy_number, type, coverage_amount, premium_amount) VALUES (?, ?, ?, ?)";
    private static final String SELECT_ALL_POLICIES_SQL = "SELECT * FROM Policy";
    private static final String UPDATE_POLICY_SQL = "UPDATE Policy SET policy_number = ?, type = ?, coverage_amount = ?, premium_amount = ? WHERE policy_id = ?";
    private static final String DELETE_POLICY_SQL = "DELETE FROM Policy WHERE policy_id = ?";

    public void addPolicy(Policy policy) throws SQLException {
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(INSERT_POLICY_SQL)) {
            preparedStatement.setString(1, policy.getPolicyNumber());
            preparedStatement.setString(2, policy.getType());
            preparedStatement.setDouble(3, policy.getCoverageAmount());
            preparedStatement.setDouble(4, policy.getPremiumAmount());
            preparedStatement.executeUpdate();
        }
    }

    public List<Policy> getAllPolicies() throws SQLException {
        List<Policy> policies = new ArrayList<>();
        try (Connection connection = DBConnection.getConnection();
             Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(SELECT_ALL_POLICIES_SQL)) {
            while (resultSet.next()) {
                Policy policy = new Policy();
                policy.setPolicyId(resultSet.getInt("policy_id"));
                policy.setPolicyNumber(resultSet.getString("policy_number"));
                policy.setType(resultSet.getString("type"));
                policy.setCoverageAmount(resultSet.getDouble("coverage_amount"));
                policy.setPremiumAmount(resultSet.getDouble("premium_amount"));
                policies.add(policy);
            }
        }
        return policies;
    }

    public void updatePolicy(Policy policy) throws SQLException {
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(UPDATE_POLICY_SQL)) {
            preparedStatement.setString(1, policy.getPolicyNumber());
            preparedStatement.setString(2, policy.getType());
            preparedStatement.setDouble(3, policy.getCoverageAmount());
            preparedStatement.setDouble(4, policy.getPremiumAmount());
            preparedStatement.setInt(5, policy.getPolicyId());
            preparedStatement.executeUpdate();
        }
    }

    public void deletePolicy(int policyId) throws SQLException {
        try (Connection connection = DBConnection.getConnection();
             PreparedStatement preparedStatement = connection.prepareStatement(DELETE_POLICY_SQL)) {
            preparedStatement.setInt(1, policyId);
            preparedStatement.executeUpdate();
        }
    }
}

