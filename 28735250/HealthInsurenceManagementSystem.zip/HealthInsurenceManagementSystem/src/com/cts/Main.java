package com.cts;

import com.cts.model.Policy;
import com.cts.model.Member;
import com.cts.model.Claim;
import com.cts.service.PolicyService;
import com.cts.service.MemberService;
import com.cts.service.ClaimService;

import java.util.List;
import java.util.Scanner;

public class Main {
    private static final PolicyService policyService = new PolicyService();
    private static final MemberService memberService = new MemberService();
    private static final ClaimService claimService = new ClaimService();

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("\nHealth Insurance Management System");
        System.out.println("1. Add Policy");
        System.out.println("2. View All Policies");
        System.out.println("3. Update Policy");
        System.out.println("4. Delete Policy");
        System.out.println("5. Add Member");
        System.out.println("6. View All Members");
        System.out.println("7. Update Member");
        System.out.println("8. Delete Member");
        System.out.println("9. Submit Claim");
        System.out.println("10. View All Claims");
        System.out.println("11. Update Claim");
        System.out.println("12. Delete Claim");
        System.out.println("13. Exit");
        System.out.print("Enter your choice: ");
        int choice = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        switch (choice) {
            case 1:
                addPolicy(scanner);
                break;
            case 2:
                viewAllPolicies();
                break;
            case 3:
                updatePolicy(scanner);
                break;
            case 4:
                deletePolicy(scanner);
                break;
            case 5:
                addMember(scanner);
                break;
            case 6:
                viewAllMembers();
                break;
            case 7:
                updateMember(scanner);
                break;
            case 8:
                deleteMember(scanner);
                break;
            case 9:
                submitClaim(scanner);
                break;
            case 10:
                viewAllClaims();
                break;
            case 11:
                updateClaim(scanner);
                break;
            case 12:
                deleteClaim(scanner);
                break;
            case 13:
                System.out.println("Exiting the application...");
                break;
            default:
                System.out.println("Invalid choice. Exiting the application...");
                break;
        }

        scanner.close();
    }

    private static void addPolicy(Scanner scanner) {
        System.out.println("\nEnter Policy Details:");
        System.out.print("Policy Number: ");
        String policyNumber = scanner.nextLine();
        System.out.print("Type: ");
        String type = scanner.nextLine();
        System.out.print("Coverage Amount: ");
        double coverageAmount = scanner.nextDouble();
        System.out.print("Premium Amount: ");
        double premiumAmount = scanner.nextDouble();
        scanner.nextLine(); // Consume newline

        Policy policy = new Policy();
        policy.setPolicyNumber(policyNumber);
        policy.setType(type);
        policy.setCoverageAmount(coverageAmount);
        policy.setPremiumAmount(premiumAmount);

        policyService.addPolicy(policy);
        System.out.println("Policy added successfully.");
    }

    private static void viewAllPolicies() {
        List<Policy> policies = policyService.getAllPolicies();
        System.out.println("\nAll Policies:");
        for (Policy policy : policies) {
            System.out.println(policy);
        }
    }

    private static void updatePolicy(Scanner scanner) {
        System.out.print("\nEnter Policy ID to update: ");
        int policyId = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        System.out.print("New Policy Number: ");
        String policyNumber = scanner.nextLine();
        System.out.print("New Type: ");
        String type = scanner.nextLine();
        System.out.print("New Coverage Amount: ");
        double coverageAmount = scanner.nextDouble();
        System.out.print("New Premium Amount: ");
        double premiumAmount = scanner.nextDouble();
        scanner.nextLine(); // Consume newline

        Policy policy = new Policy();
        policy.setPolicyId(policyId);
        policy.setPolicyNumber(policyNumber);
        policy.setType(type);
        policy.setCoverageAmount(coverageAmount);
        policy.setPremiumAmount(premiumAmount);

        policyService.updatePolicy(policy);
        System.out.println("Policy updated successfully.");
    }

    private static void deletePolicy(Scanner scanner) {
        System.out.print("\nEnter Policy ID to delete: ");
        int policyId = scanner.nextInt();
        policyService.deletePolicy(policyId);
        System.out.println("Policy deleted successfully.");
    }

    private static void addMember(Scanner scanner) {
        System.out.println("Member Name:");
        String name = scanner.nextLine();
        System.out.print("Date of Birth (yyyy-mm-dd): ");
        String dob = scanner.nextLine();
        System.out.print("Email: ");
        String email = scanner.nextLine();
        System.out.print("Phone Number: ");
        String phoneNumber = scanner.nextLine();

        Member member = new Member();
        member.setName(name);
        member.setDateOfBirth(java.sql.Date.valueOf(dob));
        member.setEmail(email);
        member.setPhoneNumber(phoneNumber);

        memberService.addMember(member);
        System.out.println("Member added successfully.");
    }

    private static void viewAllMembers() {
        List<Member> members = memberService.getAllMembers();
        System.out.println("\nAll Members:");
        for (Member member : members) {
            System.out.println(member);
        }
    }

    private static void updateMember(Scanner scanner) {
        System.out.print("\nEnter Member ID to update: ");
        int memberId = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        System.out.print("New Name: ");
        String name = scanner.nextLine();
        System.out.print("New Date of Birth (yyyy-mm-dd): ");
        String dob = scanner.nextLine();
        System.out.print("New Email: ");
        String email = scanner.nextLine();
        System.out.print("New Phone Number: ");
        String phoneNumber = scanner.nextLine();

        Member member = new Member();
        member.setMemberId(memberId);
        member.setName(name);
        member.setDateOfBirth(java.sql.Date.valueOf(dob));
        member.setEmail(email);
        member.setPhoneNumber(phoneNumber);

        memberService.updateMember(member);
        System.out.println("Member updated successfully.");
    }

    private static void deleteMember(Scanner scanner) {
        System.out.print("\nEnter Member ID to delete: ");
        int memberId = scanner.nextInt();
        memberService.deleteMember(memberId);
        System.out.println("Member deleted successfully.");
    }

    private static void submitClaim(Scanner scanner) {
        System.out.println("\nEnter Claim Details:");
        System.out.print("Policy ID: ");
        int policyId = scanner.nextInt();
        System.out.print("Member ID: ");
        int memberId = scanner.nextInt();
        System.out.print("Claim Date (yyyy-mm-dd): ");
        String claimDate = scanner.next();
        System.out.print("Status: ");
        String status = scanner.next();

        Claim claim = new Claim();
        claim.setPolicyId(policyId);
        claim.setMemberId(memberId);
        claim.setClaimDate(java.sql.Date.valueOf(claimDate));
        claim.setStatus(status);

        claimService.addClaim(claim);
        System.out.println("Claim submitted successfully.");
    }

    private static void viewAllClaims() {
        List<Claim> claims = claimService.getAllClaims();
        System.out.println("\nAll Claims:");
        for (Claim claim : claims) {
            System.out.println(claim);
        }
    }

    private static void updateClaim(Scanner scanner) {
        System.out.print("\nEnter Claim ID to update: ");
        int claimId = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        System.out.print("New Policy ID: ");
        int policyId = scanner.nextInt();
        System.out.print("New Member ID: ");
        int memberId = scanner.nextInt();
        System.out.print("New Claim Date (yyyy-mm-dd): ");
        String claimDate = scanner.next();
        System.out.print("New Status: ");
        String status = scanner.next();

        Claim claim = new Claim();
        claim.setClaimId(claimId);
        claim.setPolicyId(policyId);
        claim.setMemberId(memberId);
        claim.setClaimDate(java.sql.Date.valueOf(claimDate));
        claim.setStatus(status);

        claimService.updateClaim(claim);
        System.out.println("Claim updated successfully.");
    }

    private static void deleteClaim(Scanner scanner) {
        System.out.print("\nEnter Claim ID to delete: ");
        int claimId = scanner.nextInt();
        claimService.deleteClaim(claimId);
        System.out.println("Claim deleted successfully.");
    }
}
